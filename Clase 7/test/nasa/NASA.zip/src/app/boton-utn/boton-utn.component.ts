import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-boton-utn",
  templateUrl: "./boton-utn.component.html",
  styleUrls: ["./boton-utn.component.css"]
})
export class BotonUtnComponent implements OnInit {
  titulo = "ola k ase";

  constructor() {}

  ngOnInit() {}
}
