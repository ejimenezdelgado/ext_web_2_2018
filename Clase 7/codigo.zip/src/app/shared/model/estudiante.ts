export interface Estudiante {
  id: number;
  nombre: string;
  ciudad: string;
  fotoURL?: string;
  fechaNacimiento?: string;
}
