import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { MaterialModule } from "../material/material.module";

import { MarsComponent } from "./mars.component";
import { NasaApiService } from "../shared/services/nasa-api.service";
import { LowerCasePipe } from "../shared/pipes/lower-case.pipe";

@NgModule({
  imports: [CommonModule, MaterialModule, FormsModule],
  declarations: [MarsComponent]
})
export class MarsModule {}
